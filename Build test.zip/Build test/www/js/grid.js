var grid_size=14,grid_padding=1;
$(function(){

});
function add_char(){
	var letter,color,size;
}